# Django Indic OCR Project

This project is a Django web application for detecting and recognizing text from book covers using YOLO and a custom CRNN model.

## Setup in GitHub Codespaces

1.  **Add Your Models:**
    * Place your trained YOLO model in `ocr_app/models/yolo_text_detector.pt`.
    * Place your trained CRNN model in `ocr_app/models/crnn_ocr_model.pt`.
    * Place your vocabulary file in `ocr_app/models/vocabulary.json`.

2.  **Wait for Build:** The Codespace will automatically run `post-create-command.sh` to install dependencies and run migrations. If you just pasted this script, you may need to run it manually:
    ```bash
    bash .devcontainer/post-create-command.sh
    ```

3.  **Run the Server:**
    ```bash
    python manage.py runserver 0.0.0.0:8000
    ```

4.  Click the "Open in Browser" notification to view the app.
